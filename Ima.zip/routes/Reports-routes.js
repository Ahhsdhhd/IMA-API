const express = require("express");
var router = express.Router();
var ObjectId = require("mongoose").Types.ObjectId;

var { ReportForm } = require("../models/report");
var { ExpenditureForm } = require("../models/expenditureForm");

//=>localhost:3000/BillingForm

router.get("/gcNumber/:gcNumber", (req, res) => {
  ReportForm.find({ gcNumber: req.params.gcNumber }, (err, doc) => {
    if (!err) {
      res.send(doc);
    } else {
      console.log(
        "error in retriving Form api" + JSON.stringfy(err, undefined, 2)
      );
    }
  });
});

////-----------------------------------------             BULK ADD EXPENDITURE FORM           ------------------------------------------------------------

// router.post("/bulkAdd", (req, res) => {
//   ReportForm.find(
//     {
//       gcNumber: {
//         $gte: req.body.startingGcNumber,
//         $lte: req.body.endingGcNumber,
//       },
//       typeOfForm: "gc",
//     },
//     (err, doc) => {
//       if (!err) {
//         let gcNumberArray = [];
//         let recordNumberArray = [];
//         let companyArray = [];
//         let nameArray = [];
//         let gcType = req.body.gcType
//         let countryArray = [];
//         let billNoDetails = req.body.billNoDetails;
//         let ExpenditureAmount = req.body.ExpenditureAmount;
//         let date = req.body.date;
//          let battalionArray = [];

//         let total = [];
      

//         for (let i = 0; i < doc.length; i++) {
//           // add each number to the "total"
//           total += doc[i];
//         }
//         console.log("array " + total);

//         for (const element of doc) {
//           nameArray = [element.name];
//           console.log("nameArray " + nameArray);

//           companyArray = [element.company];
//           battalionArray = [element.battalionArray]

//           gcNumberArray = [element.gcNumber];

//           countryArray = [element.country];
//         }
//         console.log("name " + nameArray); 
//         var addExpenditureForm = new ExpenditureForm({
//           recordNumber: recordNumberArray,
//           gcType: req.body.gcType,
//           gcNumber: gcNumberArray,
//           name: nameArray,
//           battalion: battalionArray,
//           company: companyArray,
//           date: req.body.date,
//           billNoDetails: req.body.billNoDetails,
//           ExpenditureAmount: req.body.ExpenditureAmount,
//         });
//         addExpenditureForm.save((err, docs) => {
//           if (!err) {
//             res.send(docs);
//           } else {
//             console.log(
//               "error in saving ExpenditureForm " + JSON.stringify(err, undefined, 2)
//             );
//           }
//         });
//       }
      
     
//     }
//   );
// });




router.post("/bulkAdd", (req, res) => {
  ReportForm.find(
    {
      gcNumber: {
        $gte: req.body.startingGcNumber,
        $lte: req.body.endingGcNumber,
      },
      typeOfForm: "gc",
    },
    (err, doc) => {
      if (!err) {
        let gcNumberArray = [];
        let recordNumberArray = [];
        let companyArray = [];
        let nameArray = [];
        let gcType = req.body.gcType
        let countryArray = [];
        let billNoDetails = req.body.billNoDetails;
        let ExpenditureAmount = req.body.ExpenditureAmount;
        let date = req.body.date;
         let battalionArray = [];

        let total = [];
      

        for (let i = 0; i < doc.length; i++) {
          // add each number to the "total"
          total += doc[i];
        }
        console.log("array " + total);

        for (const element of doc) {
          nameArray = [element.name];
          console.log("nameArray " + nameArray);

          companyArray = [element.company];
          battalionArray = [element.battalionArray]

          gcNumberArray = [element.gcNumber];

          countryArray = [element.country];
        }
        console.log("name " + nameArray); 
        var addExpenditureForm = new ExpenditureForm({
          recordNumber: recordNumberArray,
          gcType: req.body.gcType,
          gcNumber: gcNumberArray,
          name: nameArray,
          battalion: battalionArray,
          company: companyArray,
          date: req.body.date,
          billNoDetails: req.body.billNoDetails,
          ExpenditureAmount: req.body.ExpenditureAmount,
        });
        addExpenditureForm.save((err, docs) => {
          if (!err) {
            res.send(docs);
          } else {
            console.log(
              "error in saving ExpenditureForm " + JSON.stringify(err, undefined, 2)
            );
          }
        });
      }
      
     
    }
  );
});
/////report

module.exports = router;
